package com.reactive.design.patterns.orchestrator_parallel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrchestratorParallelApplicationTests {

	@Test
	void contextLoads() {
	}

}
