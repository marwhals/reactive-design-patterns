package com.reactive.design.patterns.orchestrator_parallel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrchestratorParallelApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrchestratorParallelApplication.class, args);
	}

}
