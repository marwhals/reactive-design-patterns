package com.reactive.design.patterns.bulkhead;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulkheadApplicationTests {

	@Test
	void contextLoads() {
	}

}
