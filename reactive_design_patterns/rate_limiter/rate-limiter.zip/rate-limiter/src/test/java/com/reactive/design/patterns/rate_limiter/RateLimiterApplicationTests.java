package com.reactive.design.patterns.rate_limiter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateLimiterApplicationTests {

	@Test
	void contextLoads() {
	}

}
