package com.reactive.design.patterns.timeout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
