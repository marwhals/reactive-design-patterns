package com.reactive.design.patterns.scatter_gather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScatterGatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
